<?php

namespace haxney;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\world\Position;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\item\ItemFactory;

// muqsit uses
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuEventHandler;

class Main extends PluginBase implements Listener {
  /*
  * @var data
  * variável da config.yml
  */
  public $data;
  
  public function onEnable() : void {
    $this->getLogger()->info("§ahMina ativo com sucesso.");
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->generateConfig();
    if(!InvMenuHandler::isRegistered()){
      InvMenuHandler::register($this);
    }
  }
  
  public function generateConfig() : void {
    $config = new Config($this->getDataFolder(). "config.yml", Config::YAML,
    [
      "mundo-Nome" => 0
      ]);
      $this->data = $config;
      $config->save();
      if(is_numeric($this->data->get("mundo-nome"))){
        throw \Exception ("[hMina]Erro de Configuração na sua yml.", 1);
      }
  }
  
  public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
    switch($cmd->getName()){
      case "mina";
      if(!$sender->hasPermission("mina.perm")){
        $sender->sendMessage("§8[§ahMina§8]§f: Voce §cnao §fpossui permissao para executar este comando. Contate um staff.");
        return false;
      }
      $menu = InvMenu::create(InvMenu::TYPE_CHEST);
      $menu->setName("§fMenu da §aMina!");
      $invMenu = $menu->getInventory();
      $playerHead = ItemFactory::getInstance()->get(397, 3, 1);
      $invMenu->setItem(11, $playerHead);
      $lapis = ItemFactory::getInstance()->get(21, 0, 1);
      $lapis->setCustomName("§eVenda seus drops!");
      $invMenu->setItem(13, $lapis);
      $bar = ItemFactory::getInstance()->get(101, 0, 1);
      $bar->setCustomName("§cSair do Mundo Mina.");
      $invMenu->setItem(15, $bar);
      $paper = ItemFactory::getInstance()->get(339, 0, 1);
      $invMenu->setItem(12, $paper);
      $bar->setCustomName("§eTop 10 Mineração");
      $bar->setLore(["§cEm breve!"]);
      $playerHead->setCustomName("§aOlá, Jogador.");
      $playerHead->setLore(["§cVoce está no mundo Mina!"]);
      $menu->send($sender);
      break;
    }
    return true;
  }
}